package adt.splaytree;

import adt.bst.BSTImpl;
import adt.bst.BSTNode;

public class SplayTreeImpl<T extends Comparable<T>> extends BSTImpl<T>
		implements SplayTree<T> {

	private void splay(BSTNode<T> node) {
		// TODO Implement your code here
		throw new UnsupportedOperationException("Not impemented yet!");
	}
}
